#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cmath>

namespace py = pybind11;

struct Vector3 {
    double x = 0.0, y = 0.0, z = 0.0;
    double length() const {
        return std::sqrt(x * x + y * y + z * z);
    }
    Vector3 operator-(const Vector3& other) const {
        return {x - other.x, y - other.y, z - other.z};
    }
};

struct ObjectProperties {
    double volume = 0.0;
    double surface_area = 0.0;
    double curvature = 0.0;
    size_t vertex_count = 0;
    size_t polygon_count = 0;
    Vector3 scale;
    Vector3 dimensions;
    std::vector<double> spatial_distribution;
    std::vector<double> edge_lengths;
};

double calculate_similarity_cpp(const ObjectProperties& source, const ObjectProperties& target) {
    double similarity_score = 0.0;
    
    // Weights matching your Python script
    const double w_scale = 0.1;
    const double w_volume = 0.1;
    const double w_vertex_count = 0.05;
    const double w_face_count = 0.05;
    const double w_edge_length = 0.15;
    const double w_surface_area = 0.1;
    const double w_curvature = 0.1;
    const double w_spatial_distribution = 0.1;
    
    Vector3 scale_diff = source.scale - target.scale;
    similarity_score += w_scale * (1.0 / (1.0 + scale_diff.length()));

    if (std::max(source.volume, target.volume) > 0) {
        similarity_score += w_volume * (std::min(source.volume, target.volume) / std::max(source.volume, target.volume));
    }

    if (std::max(source.surface_area, target.surface_area) > 0) {
        similarity_score += w_surface_area * (std::min(source.surface_area, target.surface_area) / std::max(source.surface_area, target.surface_area));
    }

    double curve_diff = std::abs(source.curvature - target.curvature);
    similarity_score += w_curvature * (1.0 / (1.0 + curve_diff));

    if (source.spatial_distribution.size() == 2 && target.spatial_distribution.size() == 2) {
        double dist_diff = std::sqrt(std::pow(source.spatial_distribution[0] - target.spatial_distribution[0], 2) +
                                     std::pow(source.spatial_distribution[1] - target.spatial_distribution[1], 2));
        similarity_score += w_spatial_distribution * (1.0 / (1.0 + dist_diff));
    }
    
    size_t max_verts = std::max({(size_t)1, source.vertex_count, target.vertex_count});
    similarity_score += w_vertex_count * (static_cast<double>(std::min(source.vertex_count, target.vertex_count)) / max_verts);

    size_t max_polys = std::max({(size_t)1, source.polygon_count, target.polygon_count});
    similarity_score += w_face_count * (static_cast<double>(std::min(source.polygon_count, target.polygon_count)) / max_polys);

    size_t min_edges = std::min(source.edge_lengths.size(), target.edge_lengths.size());
    if (min_edges > 0) {
        std::vector<double> source_edges = source.edge_lengths;
        std::vector<double> target_edges = target.edge_lengths;
        std::sort(source_edges.begin(), source_edges.end());
        std::sort(target_edges.begin(), target_edges.end());
        double edge_diff_sum = 0.0;
        for (size_t i = 0; i < min_edges; ++i) {
            edge_diff_sum += std::abs(source_edges[i] - target_edges[i]);
        }
        similarity_score += w_edge_length * (1.0 / (1.0 + (edge_diff_sum / min_edges)));
    }

    // Simplified weights from Python script add up to ~0.8. We ignore location, rotation, and UVs for this main calculation.
    // The final score is normalized based on the weights used.
    double total_weights = w_scale + w_volume + w_vertex_count + w_face_count + w_edge_length + w_surface_area + w_curvature + w_spatial_distribution;
    return similarity_score / total_weights;
}

double calculate_enhanced_similarity_cpp(const ObjectProperties& source, const ObjectProperties& target) {
    double base_similarity = calculate_similarity_cpp(source, target);

    double vert_ratio = static_cast<double>(std::min(source.vertex_count, target.vertex_count)) /
                        std::max({(size_t)1, source.vertex_count, target.vertex_count});

    double face_ratio = static_cast<double>(std::min(source.polygon_count, target.polygon_count)) /
                        std::max({(size_t)1, source.polygon_count, target.polygon_count});
                        
    double topology_score = (vert_ratio + face_ratio) / 2.0;

    double bbox_score = 0.0;
    if (source.dimensions.x > 0 && target.dimensions.x > 0 &&
        source.dimensions.y > 0 && target.dimensions.y > 0 &&
        source.dimensions.z > 0 && target.dimensions.z > 0) {
        
        double ratio_x = std::min(source.dimensions.x, target.dimensions.x) / std::max(source.dimensions.x, target.dimensions.x);
        double ratio_y = std::min(source.dimensions.y, target.dimensions.y) / std::max(source.dimensions.y, target.dimensions.y);
        double ratio_z = std::min(source.dimensions.z, target.dimensions.z) / std::max(source.dimensions.z, target.dimensions.z);
        bbox_score = (ratio_x + ratio_y + ratio_z) / 3.0;
    }

    return base_similarity * 0.6 + topology_score * 0.2 + bbox_score * 0.2;
}


PYBIND11_MODULE(amoa_cpp, m) {
    m.doc() = "C++ core module for the AMOA addon";

    py::class_<Vector3>(m, "Vector3")
        .def(py::init<>())
        .def_readwrite("x", &Vector3::x)
        .def_readwrite("y", &Vector3::y)
        .def_readwrite("z", &Vector3::z);

    py::class_<ObjectProperties>(m, "ObjectProperties")
        .def(py::init<>())
        .def_readwrite("volume", &ObjectProperties::volume)
        .def_readwrite("surface_area", &ObjectProperties::surface_area)
        .def_readwrite("curvature", &ObjectProperties::curvature)
        .def_readwrite("vertex_count", &ObjectProperties::vertex_count)
        .def_readwrite("polygon_count", &ObjectProperties::polygon_count)
        .def_readwrite("scale", &ObjectProperties::scale)
        .def_readwrite("dimensions", &ObjectProperties::dimensions)
        .def_readwrite("spatial_distribution", &ObjectProperties::spatial_distribution)
        .def_readwrite("edge_lengths", &ObjectProperties::edge_lengths);
    
    m.def("calculate_enhanced_similarity", &calculate_enhanced_similarity_cpp, "Calculates enhanced similarity between two objects");
}